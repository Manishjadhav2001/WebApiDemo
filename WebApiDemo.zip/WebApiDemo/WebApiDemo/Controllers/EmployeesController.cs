﻿using Microsoft.AspNetCore.Mvc;
using WebApiDemo.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApiDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        // GET: api/<EmployeesController>
        [HttpGet]
        public IEnumerable<EmployeeViewModel> Get()
        {
            return emplist;
        }

        // GET api/<EmployeesController>/5
       static List<EmployeeViewModel> emplist = new List<EmployeeViewModel>()
        {
          new EmployeeViewModel {Empid = 1,Empname="Manish",Deptno=10 },
          new EmployeeViewModel {Empid = 2,Empname="Shivam",Deptno=20 },
          new EmployeeViewModel {Empid = 3,Empname="Amit",Deptno=30},
          new EmployeeViewModel {Empid = 4,Empname="Suresh",Deptno=40}
        };
        [HttpGet("{id}")]

        public EmployeeViewModel Get(int id)
        {
            EmployeeViewModel emp = emplist.Find(e=>e.Empid == id);
            return emp;
        }

        // POST api/<EmployeesController>
        [HttpPost]
        public void Post([FromBody] EmployeeViewModel value)
        {
            emplist.Add(value);
        }

        // PUT api/<EmployeesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] EmployeeViewModel value)
        {
            EmployeeViewModel model= emplist.FirstOrDefault(e=>e.Empid == id);
            model.Empname = value.Empname;
            model.Deptno = value.Deptno;

        }

        // DELETE api/<EmployeesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            EmployeeViewModel model = emplist.FirstOrDefault(e => e.Empid == id);
            emplist.Remove(model);
        }
    }
}
