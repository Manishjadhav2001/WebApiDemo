﻿namespace WebApiDemo.Models
{
    public class EmployeeViewModel
    {
        public int Empid { get; set; }

        public string Empname { get; set; }

        public int Deptno { get; set; }

    }
}
